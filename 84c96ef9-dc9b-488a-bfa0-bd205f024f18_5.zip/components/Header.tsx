'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const notifications = [
    { id: 1, message: "Sarah Johnson posted new content", time: "2 min ago", unread: true },
    { id: 2, message: "You received a new tip", time: "5 min ago", unread: true },
    { id: 3, message: "Emma Wilson is now live", time: "1 hour ago", unread: false },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50 border-b border-gray-200">
      <div className="max-w-full mx-auto px-4">
        <div className="flex justify-between items-center h-16">
          {/* Left side - Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <i className="ri-user-star-fill text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-blue-600">
                OnlyFans
              </span>
            </Link>
          </div>

          {/* Center - Search bar */}
          <div className="flex-1 max-w-lg mx-8">
            <div className="relative">
              <input
                type="text"
                placeholder="Search for creators..."
                className="w-full px-4 py-2 pl-10 border border-gray-300 rounded-full focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 text-sm"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
          </div>

          {/* Right side - User actions */}
          <div className="flex items-center space-x-4">
            {!isLoggedIn ? (
              <div className="flex items-center space-x-3">
                <Link href="/login">
                  <button className="text-gray-700 hover:text-blue-600 font-medium cursor-pointer">
                    Login
                  </button>
                </Link>
                <Link href="/register">
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-full hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                    Sign up for free
                  </button>
                </Link>
              </div>
            ) : (
              <div className="flex items-center space-x-3">
                {/* Create Post */}
                <button className="p-2 hover:bg-gray-100 rounded-full cursor-pointer">
                  <i className="ri-add-line text-xl text-gray-600"></i>
                </button>

                {/* Messages */}
                <Link href="/messages">
                  <button className="p-2 hover:bg-gray-100 rounded-full cursor-pointer relative">
                    <i className="ri-message-2-line text-xl text-gray-600"></i>
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center">
                      3
                    </span>
                  </button>
                </Link>

                {/* Notifications */}
                <div className="relative">
                  <button
                    onClick={() => setShowNotifications(!showNotifications)}
                    className="p-2 hover:bg-gray-100 rounded-full cursor-pointer relative"
                  >
                    <i className="ri-notification-line text-xl text-gray-600"></i>
                    <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                      2
                    </span>
                  </button>
                  
                  {showNotifications && (
                    <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                      <div className="px-4 py-2 border-b border-gray-100">
                        <h3 className="font-semibold text-gray-900">Notifications</h3>
                      </div>
                      {notifications.map((notification) => (
                        <div key={notification.id} className={`px-4 py-3 hover:bg-gray-50 cursor-pointer ${notification.unread ? 'bg-blue-50' : ''}`}>
                          <p className="text-sm text-gray-800">{notification.message}</p>
                          <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Profile Menu */}
                <div className="relative">
                  <button
                    onClick={() => setShowProfileMenu(!showProfileMenu)}
                    className="flex items-center space-x-2 hover:bg-gray-100 rounded-full p-1 cursor-pointer"
                  >
                    <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-sm font-bold">M</span>
                    </div>
                    <i className="ri-arrow-down-s-line text-gray-600"></i>
                  </button>

                  {showProfileMenu && (
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                      <div className="px-4 py-3 border-b border-gray-100">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">M</span>
                          </div>
                          <div>
                            <p className="font-semibold text-gray-900">My Profile</p>
                            <p className="text-sm text-gray-500">@myprofile</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="py-2">
                        <Link href="/profile">
                          <button className="w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 cursor-pointer">
                            <i className="ri-user-line text-gray-600"></i>
                            <span>My profile</span>
                          </button>
                        </Link>
                        <Link href="/settings">
                          <button className="w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 cursor-pointer">
                            <i className="ri-settings-line text-gray-600"></i>
                            <span>Settings</span>
                          </button>
                        </Link>
                        <Link href="/earnings">
                          <button className="w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 cursor-pointer">
                            <i className="ri-money-dollar-circle-line text-gray-600"></i>
                            <span>Earnings</span>
                          </button>
                        </Link>
                        <Link href="/subscriptions">
                          <button className="w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 cursor-pointer">
                            <i className="ri-user-follow-line text-gray-600"></i>
                            <span>Subscriptions</span>
                          </button>
                        </Link>
                        <div className="border-t border-gray-100 mt-2 pt-2">
                          <button className="w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 text-red-600 cursor-pointer">
                            <i className="ri-logout-box-line"></i>
                            <span>Log out</span>
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}