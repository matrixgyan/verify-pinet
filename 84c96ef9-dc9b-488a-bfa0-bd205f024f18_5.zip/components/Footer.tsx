
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <i className="ri-play-fill text-white text-xl"></i>
              </div>
              <span className="text-2xl font-bold" style={{fontFamily: 'Pacifico, serif'}}>VideoShare</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              The ultimate video sharing platform where creativity meets community. Share your stories, connect with audiences, and grow your following with our powerful tools and features.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-blue-500"></i>
              </div>
              <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-twitter-fill text-blue-400"></i>
              </div>
              <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-instagram-line text-pink-500"></i>
              </div>
              <div className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-gray-700 transition-colors cursor-pointer">
                <i className="ri-youtube-fill text-red-500"></i>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Platform</h3>
            <ul className="space-y-2">
              <li><Link href="/explore" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Explore</Link></li>
              <li><Link href="/trending" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Trending</Link></li>
              <li><Link href="/categories" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Categories</Link></li>
              <li><Link href="/creator" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Creator Studio</Link></li>
              <li><Link href="/analytics" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Analytics</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><Link href="/help" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Help Center</Link></li>
              <li><Link href="/community" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Community</Link></li>
              <li><Link href="/guidelines" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Guidelines</Link></li>
              <li><Link href="/safety" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Safety</Link></li>
              <li><Link href="/contact" className="text-gray-400 hover:text-white transition-colors cursor-pointer">Contact Us</Link></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 VideoShare. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/privacy" className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">
              Privacy Policy
            </Link>
            <Link href="/terms" className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">
              Terms of Service
            </Link>
            <Link href="/cookies" className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">
              Cookie Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
