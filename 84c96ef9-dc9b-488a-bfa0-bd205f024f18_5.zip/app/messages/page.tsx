
'use client';

import Header from '@/components/Header';
import { useState } from 'react';

export default function MessagesPage() {
  const [selectedChat, setSelectedChat] = useState(1);
  const [newMessage, setNewMessage] = useState('');

  const chats = [
    {
      id: 1,
      name: "Sarah Johnson",
      username: "@sarahj",
      avatar: "https://readdy.ai/api/search-image?query=professional%20woman%20portrait%20photographer%20model%20beautiful%20natural%20lighting%20headshot%20studio%20photography&width=48&height=48&seq=msg1&orientation=squarish",
      lastMessage: "Thanks for subscribing! 💕",
      timestamp: "2 min ago",
      unread: 2,
      isOnline: true
    },
    {
      id: 2,
      name: "Emma Wilson",
      username: "@emmaw",
      avatar: "https://readdy.ai/api/search-image?query=young%20woman%20portrait%20natural%20beauty%20soft%20lighting%20professional%20headshot%20photography%20studio&width=48&height=48&seq=msg2&orientation=squarish",
      lastMessage: "Here's the exclusive content you requested",
      timestamp: "1 hour ago",
      unread: 0,
      isOnline: false
    },
    {
      id: 3,
      name: "Maya Rodriguez",
      username: "@mayar",
      avatar: "https://readdy.ai/api/search-image?query=latina%20woman%20portrait%20professional%20photography%20beautiful%20natural%20lighting%20headshot%20studio&width=48&height=48&seq=msg3&orientation=squarish",
      lastMessage: "Can't wait to show you what I'm working on!",
      timestamp: "3 hours ago",
      unread: 1,
      isOnline: true
    }
  ];

  const messages = [
    {
      id: 1,
      senderId: 1,
      senderName: "Sarah Johnson",
      content: "Hey! Thanks so much for subscribing to my content! 💕",
      timestamp: "2:30 PM",
      isOwn: false
    },
    {
      id: 2,
      senderId: 'me',
      senderName: "Me",
      content: "Hi Sarah! I love your photography work. Looking forward to more content!",
      timestamp: "2:32 PM",
      isOwn: true
    },
    {
      id: 3,
      senderId: 1,
      senderName: "Sarah Johnson",
      content: "That means the world to me! I have some amazing shoots coming up this week that I think you'll love 📸✨",
      timestamp: "2:35 PM",
      isOwn: false
    },
    {
      id: 4,
      senderId: 1,
      senderName: "Sarah Johnson",
      content: "I'm also planning to do a live session soon where I'll be sharing some behind-the-scenes content. Would you be interested?",
      timestamp: "2:36 PM",
      isOwn: false
    },
    {
      id: 5,
      senderId: 'me',
      senderName: "Me",
      content: "Absolutely! That sounds amazing. When are you planning to go live?",
      timestamp: "2:38 PM",
      isOwn: true
    },
    {
      id: 6,
      senderId: 1,
      senderName: "Sarah Johnson",
      content: "Probably this Friday evening around 8 PM EST. I'll send you a notification when I'm about to start!",
      timestamp: "2:40 PM",
      isOwn: false
    }
  ];

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      console.log('Sending message:', newMessage);
      setNewMessage('');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 h-[calc(100vh-200px)] flex">
          {/* Chat List */}
          <div className="w-1/3 border-r border-gray-200 flex flex-col">
            <div className="p-4 border-b border-gray-200">
              <h2 className="text-xl font-bold text-gray-900">Messages</h2>
            </div>
            
            <div className="flex-1 overflow-y-auto">
              {chats.map((chat) => (
                <div
                  key={chat.id}
                  onClick={() => setSelectedChat(chat.id)}
                  className={`p-4 border-b border-gray-100 cursor-pointer hover:bg-gray-50 ${
                    selectedChat === chat.id ? 'bg-blue-50 border-blue-200' : ''
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <img
                        src={chat.avatar}
                        alt={chat.name}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                      {chat.isOnline && (
                        <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-gray-900 truncate">{chat.name}</p>
                        <span className="text-xs text-gray-500">{chat.timestamp}</span>
                      </div>
                      <p className="text-sm text-gray-600 truncate">{chat.lastMessage}</p>
                    </div>
                    {chat.unread > 0 && (
                      <div className="w-5 h-5 bg-blue-600 text-white text-xs rounded-full flex items-center justify-center">
                        {chat.unread}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Chat Window */}
          <div className="flex-1 flex flex-col">
            {selectedChat ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b border-gray-200 flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="relative">
                      <img
                        src={chats.find(c => c.id === selectedChat)?.avatar}
                        alt=""
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      {chats.find(c => c.id === selectedChat)?.isOnline && (
                        <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{chats.find(c => c.id === selectedChat)?.name}</p>
                      <p className="text-sm text-gray-500">{chats.find(c => c.id === selectedChat)?.isOnline ? 'Online' : 'Offline'}</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button className="p-2 hover:bg-gray-100 rounded-full cursor-pointer">
                      <i className="ri-phone-line text-gray-600"></i>
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-full cursor-pointer">
                      <i className="ri-video-line text-gray-600"></i>
                    </button>
                    <button className="p-2 hover:bg-gray-100 rounded-full cursor-pointer">
                      <i className="ri-more-2-line text-gray-600"></i>
                    </button>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.isOwn ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-xs lg:max-w-md px-4 py-2 rounded-2xl ${
                          message.isOwn
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-900'
                        }`}
                      >
                        <p className="text-sm">{message.content}</p>
                        <p className={`text-xs mt-1 ${message.isOwn ? 'text-blue-200' : 'text-gray-500'}`}>
                          {message.timestamp}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Message Input */}
                <div className="p-4 border-t border-gray-200">
                  <form onSubmit={handleSendMessage} className="flex items-center space-x-2">
                    <button
                      type="button"
                      className="p-2 hover:bg-gray-100 rounded-full cursor-pointer"
                    >
                      <i className="ri-attachment-line text-gray-600"></i>
                    </button>
                    <input
                      type="text"
                      placeholder="Type a message..."
                      className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                    />
                    <button
                      type="submit"
                      className="p-2 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors cursor-pointer"
                    >
                      <i className="ri-send-plane-fill"></i>
                    </button>
                  </form>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <i className="ri-message-2-line text-4xl mb-4"></i>
                  <p>Select a conversation to start messaging</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
