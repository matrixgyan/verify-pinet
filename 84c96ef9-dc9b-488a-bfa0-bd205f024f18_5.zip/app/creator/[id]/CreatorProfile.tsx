
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';

interface CreatorProfileProps {
  creatorId: string;
}

export default function CreatorProfile({ creatorId }: CreatorProfileProps) {
  const [activeTab, setActiveTab] = useState('posts');
  const [isSubscribed, setIsSubscribed] = useState(false);

  const creator = {
    id: creatorId,
    name: "Sarah Johnson",
    username: "@sarahj",
    avatar: "https://readdy.ai/api/search-image?query=professional%20woman%20portrait%20photographer%20model%20beautiful%20natural%20lighting%20headshot%20studio%20photography&width=120&height=120&seq=pav1&orientation=squarish",
    coverImage: "https://readdy.ai/api/search-image?query=lifestyle%20photography%20studio%20setup%20professional%20lighting%20equipment%20creative%20workspace%20modern%20aesthetic%20clean%20background&width=1200&height=400&seq=pcv1&orientation=landscape",
    bio: "Professional photographer sharing behind-the-scenes content, tutorials, and exclusive shoots. Join me on my creative journey! 📸✨",
    subscribers: "12.3K",
    subscriptionPrice: "9.99",
    posts: 145,
    likes: "2.1K",
    isOnline: true,
    joinedDate: "March 2023",
    location: "New York, NY"
  };

  const posts = [
    {
      id: 1,
      type: 'image',
      content: "Behind the scenes of today's studio session! The lighting was absolutely perfect ✨",
      media: "https://readdy.ai/api/search-image?query=photography%20studio%20behind%20scenes%20photographer%20model%20lighting%20equipment%20professional%20setup%20creative%20workspace&width=400&height=500&seq=cp1&orientation=portrait",
      likes: 234,
      comments: 18,
      timestamp: "2 hours ago",
      isLocked: false
    },
    {
      id: 2,
      type: 'image',
      content: "Exclusive content for my subscribers! This shoot was incredible 🔥",
      media: "https://readdy.ai/api/search-image?query=professional%20portrait%20photography%20model%20beautiful%20lighting%20artistic%20composition%20studio%20photography&width=400&height=500&seq=cp2&orientation=portrait",
      likes: 189,
      comments: 12,
      timestamp: "1 day ago",
      isLocked: true
    },
    {
      id: 3,
      type: 'video',
      content: "Tutorial: How I achieve this lighting setup in my studio",
      media: "https://readdy.ai/api/search-image?query=photography%20tutorial%20lighting%20setup%20studio%20equipment%20professional%20photographer%20teaching%20educational%20content&width=400&height=500&seq=cp3&orientation=portrait",
      likes: 156,
      comments: 23,
      timestamp: "3 days ago",
      isLocked: false
    }
  ];

  const subscriptionTiers = [
    {
      name: "Monthly",
      price: "$9.99",
      period: "per month",
      savings: null
    },
    {
      name: "3 Months",
      price: "$24.99",
      period: "every 3 months",
      savings: "Save 17%"
    },
    {
      name: "Annual",
      price: "$89.99",
      period: "per year",
      savings: "Save 25%"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 py-6">
        {/* Cover Image */}
        <div className="relative h-80 rounded-2xl overflow-hidden mb-6">
          <img
            src={creator.coverImage}
            alt="Cover"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/20"></div>
        </div>

        {/* Profile Info */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-6">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
            <div className="flex items-center space-x-6 mb-4 md:mb-0">
              <div className="relative">
                <img
                  src={creator.avatar}
                  alt={creator.name}
                  className="w-24 h-24 rounded-full object-cover border-4 border-white shadow-lg"
                />
                {creator.isOnline && (
                  <div className="absolute bottom-2 right-2 w-6 h-6 bg-green-500 rounded-full border-3 border-white"></div>
                )}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{creator.name}</h1>
                <p className="text-gray-600 mb-2">{creator.username}</p>
                <div className="flex items-center space-x-4 text-sm text-gray-500">
                  <span>{creator.subscribers} subscribers</span>
                  <span>•</span>
                  <span>{creator.posts} posts</span>
                  <span>•</span>
                  <span>{creator.likes} likes</span>
                  <span>•</span>
                  <span>Joined {creator.joinedDate}</span>
                </div>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <button className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap">
                <i className="ri-message-2-line"></i>
                <span>Message</span>
              </button>
              <button
                onClick={() => setIsSubscribed(!isSubscribed)}
                className={`px-6 py-2 rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap ${
                  isSubscribed
                    ? 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    : 'bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:from-blue-700 hover:to-purple-700'
                }`}
              >
                {isSubscribed ? 'Subscribed' : `Subscribe $${creator.subscriptionPrice}/month`}
              </button>
            </div>
          </div>
          
          <div className="mt-4">
            <p className="text-gray-700">{creator.bio}</p>
          </div>
        </div>

        {/* Subscription Tiers */}
        {!isSubscribed && (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 mb-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Subscription Options</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {subscriptionTiers.map((tier, index) => (
                <div key={index} className="border border-gray-200 rounded-lg p-4 hover:border-blue-500 transition-colors cursor-pointer">
                  <div className="text-center">
                    <h3 className="font-semibold text-gray-900">{tier.name}</h3>
                    <div className="text-2xl font-bold text-blue-600 my-2">{tier.price}</div>
                    <div className="text-sm text-gray-500 mb-2">{tier.period}</div>
                    {tier.savings && (
                      <div className="text-sm text-green-600 font-medium">{tier.savings}</div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Content Tabs */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 mb-6">
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('posts')}
              className={`px-6 py-4 font-medium cursor-pointer ${
                activeTab === 'posts'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Posts ({creator.posts})
            </button>
            <button
              onClick={() => setActiveTab('about')}
              className={`px-6 py-4 font-medium cursor-pointer ${
                activeTab === 'about'
                  ? 'border-b-2 border-blue-500 text-blue-600'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              About
            </button>
          </div>
        </div>

        {/* Content */}
        {activeTab === 'posts' ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {posts.map((post) => (
              <div key={post.id} className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div className="relative">
                  <img
                    src={post.media}
                    alt="Post content"
                    className="w-full h-64 object-cover"
                  />
                  {post.type === 'video' && (
                    <div className="absolute top-4 right-4 bg-black/60 text-white px-2 py-1 rounded text-sm">
                      <i className="ri-play-fill mr-1"></i>
                      Video
                    </div>
                  )}
                  {post.isLocked && (
                    <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                      <div className="text-center text-white">
                        <i className="ri-lock-fill text-2xl mb-2"></i>
                        <p className="text-sm">Subscribe to unlock</p>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="p-4">
                  <p className="text-gray-800 text-sm mb-3">{post.content}</p>
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <div className="flex items-center space-x-4">
                      <span className="flex items-center">
                        <i className="ri-heart-line mr-1"></i>
                        {post.likes}
                      </span>
                      <span className="flex items-center">
                        <i className="ri-message-2-line mr-1"></i>
                        {post.comments}
                      </span>
                    </div>
                    <span>{post.timestamp}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">About {creator.name}</h2>
            <div className="space-y-4">
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Bio</h3>
                <p className="text-gray-700">{creator.bio}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Location</h3>
                <p className="text-gray-700">{creator.location}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Joined</h3>
                <p className="text-gray-700">{creator.joinedDate}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">Social Media</h3>
                <div className="flex space-x-4">
                  <button className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 cursor-pointer">
                    <i className="ri-instagram-line"></i>
                    <span>Instagram</span>
                  </button>
                  <button className="flex items-center space-x-2 text-blue-600 hover:text-blue-800 cursor-pointer">
                    <i className="ri-twitter-line"></i>
                    <span>Twitter</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}
