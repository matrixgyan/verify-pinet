'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';
import { useState } from 'react';

export default function Home() {
  const [activeTab, setActiveTab] = useState('timeline');
  
  const creators = [
    {
      id: 1,
      name: "Sarah Johnson",
      username: "sarahj",
      avatar: "https://readdy.ai/api/search-image?query=professional%20woman%20portrait%20photographer%20model%20beautiful%20natural%20lighting%20headshot%20studio%20photography&width=50&height=50&seq=av1&orientation=squarish",
      isOnline: true,
      isVerified: true,
      subscriptionPrice: "9.99"
    },
    {
      id: 2,
      name: "Emma Wilson",
      username: "emmaw",
      avatar: "https://readdy.ai/api/search-image?query=young%20woman%20portrait%20natural%20beauty%20soft%20lighting%20professional%20headshot%20photography%20studio&width=50&height=50&seq=av2&orientation=squarish",
      isOnline: false,
      isVerified: true,
      subscriptionPrice: "14.99"
    },
    {
      id: 3,
      name: "Maya Rodriguez",
      username: "mayar",
      avatar: "https://readdy.ai/api/search-image?query=latina%20woman%20portrait%20professional%20photography%20beautiful%20natural%20lighting%20headshot%20studio&width=50&height=50&seq=av3&orientation=squarish",
      isOnline: true,
      isVerified: false,
      subscriptionPrice: "7.99"
    }
  ];

  const posts = [
    {
      id: 1,
      creator: creators[0],
      content: "Good morning babes! ☀️ Just woke up and feeling amazing today. Hope you're all having a beautiful day! 💕",
      images: [
        "https://readdy.ai/api/search-image?query=morning%20selfie%20woman%20bedroom%20natural%20lighting%20beautiful%20portrait%20photography%20lifestyle%20content&width=600&height=400&seq=p1&orientation=landscape"
      ],
      likes: 847,
      comments: 34,
      tips: 12,
      timestamp: "45 minutes ago",
      isLocked: false,
      price: null
    },
    {
      id: 2,
      creator: creators[1],
      content: "Exclusive photo set from yesterday's shoot 🔥 You won't want to miss this one...",
      images: [
        "https://readdy.ai/api/search-image?query=professional%20photoshoot%20woman%20studio%20lighting%20fashion%20photography%20artistic%20composition&width=600&height=400&seq=p2&orientation=landscape"
      ],
      likes: 623,
      comments: 28,
      tips: 8,
      timestamp: "2 hours ago",
      isLocked: true,
      price: "25.00"
    },
    {
      id: 3,
      creator: creators[2],
      content: "Cooking stream was so much fun! Thanks to everyone who joined 👨‍🍳✨",
      images: [
        "https://readdy.ai/api/search-image?query=cooking%20kitchen%20lifestyle%20woman%20food%20preparation%20professional%20photography%20modern%20aesthetic&width=600&height=400&seq=p3&orientation=landscape"
      ],
      likes: 392,
      comments: 15,
      tips: 5,
      timestamp: "4 hours ago",
      isLocked: false,
      price: null
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Sidebar */}
          <div className="lg:col-span-1">
            {/* Navigation Menu */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-6">
              <nav className="space-y-2">
                <button
                  onClick={() => setActiveTab('timeline')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left cursor-pointer ${
                    activeTab === 'timeline' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <i className="ri-time-line text-lg"></i>
                  <span className="font-medium">Timeline</span>
                </button>
                <button
                  onClick={() => setActiveTab('following')}
                  className={`w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left cursor-pointer ${
                    activeTab === 'following' ? 'bg-blue-50 text-blue-600' : 'text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <i className="ri-user-follow-line text-lg"></i>
                  <span className="font-medium">Following</span>
                </button>
                <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left text-gray-700 hover:bg-gray-50 cursor-pointer">
                  <i className="ri-bookmark-line text-lg"></i>
                  <span className="font-medium">Bookmarks</span>
                </button>
                <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left text-gray-700 hover:bg-gray-50 cursor-pointer">
                  <i className="ri-history-line text-lg"></i>
                  <span className="font-medium">Recently viewed</span>
                </button>
                <button className="w-full flex items-center space-x-3 px-3 py-2 rounded-lg text-left text-gray-700 hover:bg-gray-50 cursor-pointer">
                  <i className="ri-heart-line text-lg"></i>
                  <span className="font-medium">Liked</span>
                </button>
              </nav>
            </div>

            {/* Suggestions */}
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
              <h3 className="font-semibold text-gray-900 mb-4">Suggestions</h3>
              <div className="space-y-3">
                {creators.map((creator) => (
                  <div key={creator.id} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="relative">
                        <img
                          src={creator.avatar}
                          alt={creator.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        {creator.isOnline && (
                          <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                        )}
                      </div>
                      <div>
                        <div className="flex items-center space-x-1">
                          <p className="font-medium text-sm">{creator.name}</p>
                          {creator.isVerified && (
                            <i className="ri-verified-badge-fill text-blue-500 text-xs"></i>
                          )}
                        </div>
                        <p className="text-xs text-gray-500">@{creator.username}</p>
                      </div>
                    </div>
                    <Link href={`/creator/${creator.id}`}>
                      <button className="bg-blue-600 text-white px-3 py-1 rounded-full text-xs hover:bg-blue-700 cursor-pointer whitespace-nowrap">
                        Follow
                      </button>
                    </Link>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            {/* Posts Feed */}
            <div className="space-y-6">
              {posts.map((post) => (
                <div key={post.id} className="bg-white rounded-lg shadow-sm border border-gray-200">
                  {/* Post Header */}
                  <div className="p-4 border-b border-gray-100">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className="relative">
                          <img
                            src={post.creator.avatar}
                            alt={post.creator.name}
                            className="w-12 h-12 rounded-full object-cover"
                          />
                          {post.creator.isOnline && (
                            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
                          )}
                        </div>
                        <div>
                          <div className="flex items-center space-x-1">
                            <Link href={`/creator/${post.creator.id}`}>
                              <p className="font-semibold text-gray-900 hover:text-blue-600 cursor-pointer">{post.creator.name}</p>
                            </Link>
                            {post.creator.isVerified && (
                              <i className="ri-verified-badge-fill text-blue-500 text-sm"></i>
                            )}
                          </div>
                          <p className="text-sm text-gray-500">@{post.creator.username} • {post.timestamp}</p>
                        </div>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <button className="bg-blue-600 text-white px-4 py-1 rounded-full text-sm hover:bg-blue-700 cursor-pointer whitespace-nowrap">
                          Subscribe
                        </button>
                        <button className="p-2 hover:bg-gray-100 rounded-full cursor-pointer">
                          <i className="ri-more-2-line text-gray-500"></i>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Post Content */}
                  <div className="p-4">
                    <p className="text-gray-800 mb-4">{post.content}</p>
                    
                    <div className="relative">
                      <img
                        src={post.images[0]}
                        alt="Post content"
                        className="w-full rounded-lg object-cover"
                        style={{maxHeight: '500px'}}
                      />
                      {post.isLocked && (
                        <div className="absolute inset-0 bg-black/70 rounded-lg flex items-center justify-center">
                          <div className="text-center text-white">
                            <i className="ri-lock-fill text-4xl mb-3"></i>
                            <p className="text-lg font-medium mb-2">Unlock for ${post.price}</p>
                            <p className="text-sm text-gray-300 mb-4">This content is locked</p>
                            <button className="bg-blue-600 text-white px-6 py-2 rounded-full hover:bg-blue-700 cursor-pointer whitespace-nowrap">
                              Unlock ${post.price}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Post Actions */}
                  <div className="p-4 border-t border-gray-100">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-6">
                        <button className="flex items-center space-x-2 text-gray-500 hover:text-red-500 cursor-pointer">
                          <i className="ri-heart-line text-lg"></i>
                          <span className="text-sm font-medium">{post.likes}</span>
                        </button>
                        <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500 cursor-pointer">
                          <i className="ri-message-2-line text-lg"></i>
                          <span className="text-sm font-medium">{post.comments}</span>
                        </button>
                        <button className="flex items-center space-x-2 text-gray-500 hover:text-green-500 cursor-pointer">
                          <i className="ri-gift-line text-lg"></i>
                          <span className="text-sm font-medium">{post.tips}</span>
                        </button>
                      </div>
                      <div className="flex items-center space-x-2">
                        <button className="text-gray-500 hover:text-gray-700 cursor-pointer">
                          <i className="ri-bookmark-line text-lg"></i>
                        </button>
                        <button className="text-gray-500 hover:text-gray-700 cursor-pointer">
                          <i className="ri-share-line text-lg"></i>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Load More */}
            <div className="text-center mt-8">
              <button className="bg-blue-600 text-white px-8 py-3 rounded-full hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                Load more posts
              </button>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}