'use client';

import { useState } from 'react';

export default function SubscriptionManagement() {
  const [activeTab, setActiveTab] = useState('tiers');
  const [showTierModal, setShowTierModal] = useState(false);

  const subscriptionTiers = [
    { id: 1, name: 'Free Fan', price: '$0', features: ['View public content', 'Send messages', 'Basic support'], users: 15420, active: true },
    { id: 2, name: 'Premium Fan', price: '$9.99', features: ['All Free features', 'Premium content access', 'Priority support'], users: 8930, active: true },
    { id: 3, name: 'VIP Fan', price: '$19.99', features: ['All Premium features', 'Exclusive content', 'Direct creator chat'], users: 3450, active: true },
    { id: 4, name: 'Creator Basic', price: '$29.99', features: ['Upload content', 'Basic analytics', 'Payment processing'], users: 1890, active: true },
    { id: 5, name: 'Creator Pro', price: '$49.99', features: ['All Basic features', 'Advanced analytics', 'Custom branding'], users: 567, active: true },
  ];

  const activeSubscriptions = [
    { id: 1, user: 'Sarah Johnson', plan: 'Creator Pro', amount: '$49.99', status: 'Active', renewDate: '2024-04-15', duration: '6 months' },
    { id: 2, user: 'Mike Chen', plan: 'Premium Fan', amount: '$9.99', status: 'Active', renewDate: '2024-04-10', duration: '1 month' },
    { id: 3, user: 'Emma Wilson', plan: 'VIP Fan', amount: '$19.99', status: 'Cancelled', renewDate: '2024-04-05', duration: '3 months' },
    { id: 4, user: 'Alex Brown', plan: 'Creator Basic', amount: '$29.99', status: 'Active', renewDate: '2024-04-20', duration: '1 month' },
    { id: 5, user: 'Lisa Davis', plan: 'Premium Fan', amount: '$9.99', status: 'Expired', renewDate: '2024-03-25', duration: '1 month' },
  ];

  const subscriptionAnalytics = {
    totalRevenue: 245670,
    monthlyGrowth: 12.5,
    churnRate: 3.8,
    avgSubscriptionValue: 18.50,
    conversionRate: 15.2
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Subscription Management</h2>
        <button 
          onClick={() => setShowTierModal(true)}
          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap"
        >
          <i className="ri-add-line mr-2"></i>
          Create New Tier
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${subscriptionAnalytics.totalRevenue.toLocaleString()}</p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <i className="ri-money-dollar-circle-line text-green-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Monthly Growth</p>
              <p className="text-2xl font-bold text-gray-900">{subscriptionAnalytics.monthlyGrowth}%</p>
            </div>
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <i className="ri-trending-up-line text-blue-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Churn Rate</p>
              <p className="text-2xl font-bold text-gray-900">{subscriptionAnalytics.churnRate}%</p>
            </div>
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <i className="ri-user-unfollow-line text-red-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Avg Value</p>
              <p className="text-2xl font-bold text-gray-900">${subscriptionAnalytics.avgSubscriptionValue}</p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <i className="ri-calculator-line text-purple-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Conversion</p>
              <p className="text-2xl font-bold text-gray-900">{subscriptionAnalytics.conversionRate}%</p>
            </div>
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <i className="ri-exchange-line text-orange-600 text-xl"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('tiers')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'tiers'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Subscription Tiers
            </button>
            <button
              onClick={() => setActiveTab('active')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'active'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Active Subscriptions
            </button>
            <button
              onClick={() => setActiveTab('analytics')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'analytics'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Analytics
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'tiers' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subscriptionTiers.map((tier) => (
                <div key={tier.id} className="border border-gray-200 rounded-lg p-6 hover:border-red-300 transition-colors">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-900">{tier.name}</h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      tier.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {tier.active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                  
                  <div className="text-3xl font-bold text-gray-900 mb-4">
                    {tier.price}
                    <span className="text-sm font-normal text-gray-500">/month</span>
                  </div>
                  
                  <ul className="space-y-2 mb-4">
                    {tier.features.map((feature, index) => (
                      <li key={index} className="flex items-center space-x-2">
                        <i className="ri-check-line text-green-600 text-sm"></i>
                        <span className="text-sm text-gray-600">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                    <span>{tier.users.toLocaleString()} users</span>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button className="flex-1 text-sm text-red-600 hover:text-red-700 cursor-pointer">
                      Edit
                    </button>
                    <button className="flex-1 text-sm text-gray-600 hover:text-gray-700 cursor-pointer">
                      {tier.active ? 'Disable' : 'Enable'}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'active' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-900">User</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Plan</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Amount</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Renewal Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Duration</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {activeSubscriptions.map((subscription) => (
                    <tr key={subscription.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">{subscription.user[0]}</span>
                          </div>
                          <span className="font-medium text-gray-900">{subscription.user}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-gray-900">{subscription.plan}</td>
                      <td className="py-4 px-4 font-medium text-gray-900">{subscription.amount}</td>
                      <td className="py-4 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          subscription.status === 'Active' ? 'bg-green-100 text-green-800' :
                          subscription.status === 'Cancelled' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {subscription.status}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{subscription.renewDate}</td>
                      <td className="py-4 px-4 text-gray-600">{subscription.duration}</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                            <i className="ri-eye-line text-gray-600"></i>
                          </button>
                          <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                            <i className="ri-edit-line text-gray-600"></i>
                          </button>
                          <button className="p-2 hover:bg-red-100 rounded-lg cursor-pointer">
                            <i className="ri-close-line text-red-600"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'analytics' && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Breakdown</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Premium Fan</span>
                    <span className="font-medium text-gray-900">$89,370</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">VIP Fan</span>
                    <span className="font-medium text-gray-900">$68,955</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Creator Pro</span>
                    <span className="font-medium text-gray-900">$56,833</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Creator Basic</span>
                    <span className="font-medium text-gray-900">$30,512</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Popular Features</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Premium content access</span>
                    <span className="font-medium text-gray-900">89%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Direct creator chat</span>
                    <span className="font-medium text-gray-900">76%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Advanced analytics</span>
                    <span className="font-medium text-gray-900">62%</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Custom branding</span>
                    <span className="font-medium text-gray-900">45%</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {showTierModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Create New Tier</h3>
              <button
                onClick={() => setShowTierModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tier Name</label>
                <input
                  type="text"
                  placeholder="e.g., Premium Fan"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Price (Monthly)</label>
                <input
                  type="number"
                  step="0.01"
                  placeholder="9.99"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Features</label>
                <textarea
                  placeholder="Enter features separated by commas"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  rows={3}
                ></textarea>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="active"
                  className="w-4 h-4 text-red-600 focus:ring-red-500 border-gray-300 rounded cursor-pointer"
                />
                <label htmlFor="active" className="text-sm text-gray-700 cursor-pointer">
                  Make active immediately
                </label>
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-4 mt-6">
              <button
                onClick={() => setShowTierModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
              <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
                Create Tier
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}