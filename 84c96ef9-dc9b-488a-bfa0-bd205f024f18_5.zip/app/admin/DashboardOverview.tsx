'use client';

import { useState } from 'react';

export default function DashboardOverview() {
  const [timeRange, setTimeRange] = useState('7days');

  const stats = [
    { title: 'Total Users', value: '45,892', change: '+12%', icon: 'ri-user-line', color: 'blue' },
    { title: 'Active Subscriptions', value: '12,456', change: '+8%', icon: 'ri-vip-crown-line', color: 'green' },
    { title: 'Total Revenue', value: '$234,567', change: '+15%', icon: 'ri-money-dollar-circle-line', color: 'purple' },
    { title: 'Content Posts', value: '8,901', change: '+22%', icon: 'ri-file-text-line', color: 'orange' },
  ];

  const recentActivities = [
    { user: 'Sarah Johnson', action: 'Created new subscription tier', time: '2 min ago', type: 'success' },
    { user: 'Mike Chen', action: 'Payment failed - requires attention', time: '5 min ago', type: 'warning' },
    { user: 'Emma Wilson', action: 'Uploaded new content', time: '8 min ago', type: 'info' },
    { user: 'Alex Brown', action: 'Violated community guidelines', time: '12 min ago', type: 'danger' },
    { user: 'Lisa Davis', action: 'Account verified successfully', time: '15 min ago', type: 'success' },
  ];

  const topCreators = [
    { name: 'Sarah Johnson', earnings: '$12,450', subscribers: '2,340', growth: '+18%' },
    { name: 'Emma Wilson', earnings: '$9,870', subscribers: '1,890', growth: '+25%' },
    { name: 'Mike Chen', earnings: '$8,450', subscribers: '1,567', growth: '+12%' },
    { name: 'Alex Brown', earnings: '$7,230', subscribers: '1,234', growth: '+8%' },
    { name: 'Lisa Davis', earnings: '$6,890', subscribers: '1,098', growth: '+15%' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Dashboard Overview</h2>
        <select 
          value={timeRange}
          onChange={(e) => setTimeRange(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
        >
          <option value="7days">Last 7 days</option>
          <option value="30days">Last 30 days</option>
          <option value="90days">Last 90 days</option>
          <option value="1year">Last year</option>
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900 mt-1">{stat.value}</p>
                <p className={`text-sm mt-1 ${stat.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                  {stat.change} from last period
                </p>
              </div>
              <div className={`w-12 h-12 rounded-lg flex items-center justify-center bg-${stat.color}-100`}>
                <i className={`${stat.icon} text-2xl text-${stat.color}-600`}></i>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Recent Activities</h3>
            <button className="text-sm text-red-600 hover:text-red-700 cursor-pointer">
              View all
            </button>
          </div>
          
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg">
                <div className={`w-2 h-2 rounded-full ${
                  activity.type === 'success' ? 'bg-green-500' :
                  activity.type === 'warning' ? 'bg-yellow-500' :
                  activity.type === 'danger' ? 'bg-red-500' : 'bg-blue-500'
                }`}></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">{activity.user}</p>
                  <p className="text-sm text-gray-600">{activity.action}</p>
                </div>
                <span className="text-xs text-gray-500">{activity.time}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Top Creators</h3>
            <button className="text-sm text-red-600 hover:text-red-700 cursor-pointer">
              View all
            </button>
          </div>
          
          <div className="space-y-4">
            {topCreators.map((creator, index) => (
              <div key={index} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">{creator.name[0]}</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{creator.name}</p>
                    <p className="text-xs text-gray-500">{creator.subscribers} subscribers</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900">{creator.earnings}</p>
                  <p className="text-xs text-green-600">{creator.growth}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">System Health</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <i className="ri-server-line text-2xl text-green-600"></i>
            </div>
            <p className="text-sm font-medium text-gray-900">Server Status</p>
            <p className="text-xs text-green-600">Operational</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <i className="ri-database-line text-2xl text-blue-600"></i>
            </div>
            <p className="text-sm font-medium text-gray-900">Database</p>
            <p className="text-xs text-blue-600">99.9% uptime</p>
          </div>
          
          <div className="text-center">
            <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
              <i className="ri-cloud-line text-2xl text-purple-600"></i>
            </div>
            <p className="text-sm font-medium text-gray-900">CDN</p>
            <p className="text-xs text-purple-600">Fast delivery</p>
          </div>
        </div>
      </div>
    </div>
  );
}