'use client';

import { useState } from 'react';

export default function ContentModeration() {
  const [activeTab, setActiveTab] = useState('pending');
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [selectedContent, setSelectedContent] = useState<any>(null);

  const pendingContent = [
    { id: 1, creator: 'Sarah Johnson', type: 'Image', title: 'Beach Photoshoot', reported: 3, flagged: 'Adult Content', date: '2024-03-15 10:30', priority: 'High' },
    { id: 2, creator: 'Mike Chen', type: 'Video', title: 'Workout Session', reported: 1, flagged: 'Inappropriate', date: '2024-03-15 09:15', priority: 'Medium' },
    { id: 3, creator: 'Emma Wilson', type: 'Text', title: 'Personal Story', reported: 2, flagged: 'Harassment', date: '2024-03-14 16:45', priority: 'High' },
    { id: 4, creator: 'Alex Brown', type: 'Image', title: 'Art Collection', reported: 1, flagged: 'Copyright', date: '2024-03-14 14:20', priority: 'Low' },
    { id: 5, creator: 'Lisa Davis', type: 'Video', title: 'Cooking Tutorial', reported: 0, flagged: 'Auto-flagged', date: '2024-03-14 11:30', priority: 'Low' },
  ];

  const approvedContent = [
    { id: 1, creator: 'Sarah Johnson', type: 'Image', title: 'Fashion Shoot', reviewedBy: 'Admin', date: '2024-03-15 08:00', action: 'Approved' },
    { id: 2, creator: 'Mike Chen', type: 'Video', title: 'Fitness Tips', reviewedBy: 'Moderator1', date: '2024-03-14 17:30', action: 'Approved' },
    { id: 3, creator: 'Emma Wilson', type: 'Text', title: 'Travel Blog', reviewedBy: 'Admin', date: '2024-03-14 15:15', action: 'Approved' },
  ];

  const rejectedContent = [
    { id: 1, creator: 'John Doe', type: 'Image', title: 'Inappropriate Content', reviewedBy: 'Admin', date: '2024-03-15 07:00', reason: 'Violates community guidelines' },
    { id: 2, creator: 'Jane Smith', type: 'Video', title: 'Spam Content', reviewedBy: 'Moderator2', date: '2024-03-14 16:00', reason: 'Spam/promotional content' },
    { id: 3, creator: 'Bob Wilson', type: 'Text', title: 'Hate Speech', reviewedBy: 'Admin', date: '2024-03-14 13:45', reason: 'Hate speech detected' },
  ];

  const moderationStats = {
    totalReports: 245,
    pendingReview: 12,
    approvedToday: 56,
    rejectedToday: 8
  };

  const handleReview = (content: any) => {
    setSelectedContent(content);
    setShowReviewModal(true);
  };

  const handleContentAction = (action: string) => {
    console.log(`Content ${action}:`, selectedContent);
    setShowReviewModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Content Moderation</h2>
        <div className="flex items-center space-x-4">
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 cursor-pointer whitespace-nowrap">
            <i className="ri-settings-line mr-2"></i>
            Moderation Settings
          </button>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
            <i className="ri-file-text-line mr-2"></i>
            Generate Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Reports</p>
              <p className="text-2xl font-bold text-gray-900">{moderationStats.totalReports}</p>
            </div>
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <i className="ri-flag-line text-red-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Pending Review</p>
              <p className="text-2xl font-bold text-gray-900">{moderationStats.pendingReview}</p>
            </div>
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <i className="ri-time-line text-yellow-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Approved Today</p>
              <p className="text-2xl font-bold text-gray-900">{moderationStats.approvedToday}</p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <i className="ri-check-line text-green-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Rejected Today</p>
              <p className="text-2xl font-bold text-gray-900">{moderationStats.rejectedToday}</p>
            </div>
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <i className="ri-close-line text-red-600 text-xl"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('pending')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'pending'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Pending Review ({pendingContent.length})
            </button>
            <button
              onClick={() => setActiveTab('approved')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'approved'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Approved Content
            </button>
            <button
              onClick={() => setActiveTab('rejected')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'rejected'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Rejected Content
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'pending' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Creator</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Content</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Reports</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Flagged For</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Priority</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingContent.map((content) => (
                    <tr key={content.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">{content.creator[0]}</span>
                          </div>
                          <span className="font-medium text-gray-900">{content.creator}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div>
                          <p className="font-medium text-gray-900">{content.title}</p>
                          <p className="text-sm text-gray-500">{content.type}</p>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <span className="px-2 py-1 bg-red-100 text-red-800 text-xs rounded-full">
                          {content.reported} reports
                        </span>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{content.flagged}</td>
                      <td className="py-4 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          content.priority === 'High' ? 'bg-red-100 text-red-800' :
                          content.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {content.priority}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{content.date}</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => handleReview(content)}
                            className="p-2 hover:bg-blue-100 rounded-lg cursor-pointer"
                          >
                            <i className="ri-eye-line text-blue-600"></i>
                          </button>
                          <button className="p-2 hover:bg-green-100 rounded-lg cursor-pointer">
                            <i className="ri-check-line text-green-600"></i>
                          </button>
                          <button className="p-2 hover:bg-red-100 rounded-lg cursor-pointer">
                            <i className="ri-close-line text-red-600"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'approved' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Creator</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Content</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Reviewed By</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {approvedContent.map((content) => (
                    <tr key={content.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">{content.creator[0]}</span>
                          </div>
                          <span className="font-medium text-gray-900">{content.creator}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div>
                          <p className="font-medium text-gray-900">{content.title}</p>
                          <p className="text-sm text-gray-500">{content.type}</p>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{content.reviewedBy}</td>
                      <td className="py-4 px-4 text-gray-600">{content.date}</td>
                      <td className="py-4 px-4">
                        <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                          {content.action}
                        </span>
                      </td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button className="p-2 hover:bg-blue-100 rounded-lg cursor-pointer">
                            <i className="ri-eye-line text-blue-600"></i>
                          </button>
                          <button className="p-2 hover:bg-red-100 rounded-lg cursor-pointer">
                            <i className="ri-close-line text-red-600"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'rejected' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Creator</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Content</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Reviewed By</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Reason</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {rejectedContent.map((content) => (
                    <tr key={content.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">{content.creator[0]}</span>
                          </div>
                          <span className="font-medium text-gray-900">{content.creator}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4">
                        <div>
                          <p className="font-medium text-gray-900">{content.title}</p>
                          <p className="text-sm text-gray-500">{content.type}</p>
                        </div>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{content.reviewedBy}</td>
                      <td className="py-4 px-4 text-gray-600">{content.date}</td>
                      <td className="py-4 px-4 text-gray-600">{content.reason}</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button className="p-2 hover:bg-blue-100 rounded-lg cursor-pointer">
                            <i className="ri-eye-line text-blue-600"></i>
                          </button>
                          <button className="p-2 hover:bg-green-100 rounded-lg cursor-pointer">
                            <i className="ri-refresh-line text-green-600"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showReviewModal && selectedContent && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-2/3 max-w-4xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Content Review</h3>
              <button
                onClick={() => setShowReviewModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Content Details</h4>
                <div className="space-y-3">
                  <div>
                    <span className="text-sm text-gray-600">Creator:</span>
                    <span className="ml-2 font-medium text-gray-900">{selectedContent.creator}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Title:</span>
                    <span className="ml-2 font-medium text-gray-900">{selectedContent.title}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Type:</span>
                    <span className="ml-2 font-medium text-gray-900">{selectedContent.type}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Reports:</span>
                    <span className="ml-2 font-medium text-gray-900">{selectedContent.reported}</span>
                  </div>
                  <div>
                    <span className="text-sm text-gray-600">Flagged for:</span>
                    <span className="ml-2 font-medium text-gray-900">{selectedContent.flagged}</span>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Content Preview</h4>
                  <div className="border border-gray-300 rounded-lg p-4 h-64 bg-gray-50 flex items-center justify-center">
                    <div className="text-center">
                      <i className="ri-image-line text-4xl text-gray-400 mb-2"></i>
                      <p className="text-sm text-gray-600">Content preview would appear here</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Moderation Actions</h4>
                <div className="space-y-3">
                  <button
                    onClick={() => handleContentAction('approve')}
                    className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-check-line mr-2"></i>
                    Approve Content
                  </button>
                  <button
                    onClick={() => handleContentAction('reject')}
                    className="w-full bg-red-600 text-white py-2 px-4 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-close-line mr-2"></i>
                    Reject Content
                  </button>
                  <button
                    onClick={() => handleContentAction('flag')}
                    className="w-full bg-yellow-600 text-white py-2 px-4 rounded-lg hover:bg-yellow-700 cursor-pointer whitespace-nowrap"
                  >
                    <i className="ri-flag-line mr-2"></i>
                    Flag for Review
                  </button>
                </div>
                
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Review Notes</h4>
                  <textarea
                    placeholder="Add review notes..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                    rows={4}
                  ></textarea>
                </div>
                
                <div className="mt-6">
                  <h4 className="font-semibold text-gray-900 mb-3">Quick Actions</h4>
                  <div className="space-y-2">
                    <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                      Contact Creator
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                      View Creator Profile
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                      Check Similar Content
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}