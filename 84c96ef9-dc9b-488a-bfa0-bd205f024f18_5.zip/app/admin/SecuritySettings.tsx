'use client';

import { useState } from 'react';

export default function SecuritySettings() {
  const [activeTab, setActiveTab] = useState('overview');
  const [showAddRuleModal, setShowAddRuleModal] = useState(false);

  const securityStats = {
    threats: 12,
    blockedIPs: 345,
    failedLogins: 89,
    suspiciousActivity: 24
  };

  const recentSecurityEvents = [
    { id: 1, type: 'threat', event: 'Suspicious login attempt blocked', ip: '192.168.1.100', time: '2 min ago', severity: 'high' },
    { id: 2, type: 'success', event: 'User password changed successfully', ip: '10.0.0.1', time: '5 min ago', severity: 'low' },
    { id: 3, type: 'warning', event: 'Multiple failed login attempts', ip: '172.16.0.1', time: '8 min ago', severity: 'medium' },
    { id: 4, type: 'threat', event: 'Malicious file upload blocked', ip: '203.0.113.1', time: '12 min ago', severity: 'high' },
    { id: 5, type: 'info', event: 'IP whitelist updated', ip: 'System', time: '15 min ago', severity: 'low' },
  ];

  const firewallRules = [
    { id: 1, name: 'Block Suspicious IPs', type: 'IP Block', status: 'Active', priority: 'High', lastUpdated: '2024-03-15' },
    { id: 2, name: 'Rate Limiting', type: 'Rate Limit', status: 'Active', priority: 'Medium', lastUpdated: '2024-03-14' },
    { id: 3, name: 'SQL Injection Protection', type: 'WAF Rule', status: 'Active', priority: 'High', lastUpdated: '2024-03-13' },
    { id: 4, name: 'DDoS Protection', type: 'DDoS Shield', status: 'Active', priority: 'Critical', lastUpdated: '2024-03-12' },
    { id: 5, name: 'Geo-blocking', type: 'Geo Filter', status: 'Inactive', priority: 'Low', lastUpdated: '2024-03-10' },
  ];

  const backupSchedule = [
    { id: 1, name: 'Daily Database Backup', frequency: 'Daily', lastRun: '2024-03-15 02:00', nextRun: '2024-03-16 02:00', status: 'Success' },
    { id: 2, name: 'Weekly File Backup', frequency: 'Weekly', lastRun: '2024-03-10 03:00', nextRun: '2024-03-17 03:00', status: 'Success' },
    { id: 3, name: 'Monthly Full Backup', frequency: 'Monthly', lastRun: '2024-03-01 04:00', nextRun: '2024-04-01 04:00', status: 'Success' },
    { id: 4, name: 'Config Backup', frequency: 'Daily', lastRun: '2024-03-15 01:00', nextRun: '2024-03-16 01:00', status: 'Failed' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Security Settings</h2>
        <button 
          onClick={() => setShowAddRuleModal(true)}
          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap"
        >
          <i className="ri-shield-check-line mr-2"></i>
          Add Security Rule
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Threats Blocked</p>
              <p className="text-2xl font-bold text-gray-900">{securityStats.threats}</p>
            </div>
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <i className="ri-shield-cross-line text-red-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Blocked IPs</p>
              <p className="text-2xl font-bold text-gray-900">{securityStats.blockedIPs}</p>
            </div>
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <i className="ri-forbid-line text-orange-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Failed Logins</p>
              <p className="text-2xl font-bold text-gray-900">{securityStats.failedLogins}</p>
            </div>
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <i className="ri-lock-line text-yellow-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Suspicious Activity</p>
              <p className="text-2xl font-bold text-gray-900">{securityStats.suspiciousActivity}</p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <i className="ri-eye-line text-purple-600 text-xl"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('overview')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'overview'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Security Overview
            </button>
            <button
              onClick={() => setActiveTab('firewall')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'firewall'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Firewall Rules
            </button>
            <button
              onClick={() => setActiveTab('backup')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'backup'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Backup & Recovery
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Security Events</h3>
                <div className="space-y-3">
                  {recentSecurityEvents.map((event) => (
                    <div key={event.id} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                      <div className={`w-3 h-3 rounded-full ${
                        event.severity === 'high' ? 'bg-red-500' :
                        event.severity === 'medium' ? 'bg-yellow-500' :
                        event.severity === 'low' ? 'bg-green-500' : 'bg-blue-500'
                      }`}></div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{event.event}</p>
                        <p className="text-xs text-gray-500">IP: {event.ip} • {event.time}</p>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        event.severity === 'high' ? 'bg-red-100 text-red-800' :
                        event.severity === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                        event.severity === 'low' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'
                      }`}>
                        {event.severity}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">Security Health</h4>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Firewall Status</span>
                      <span className="text-sm font-medium text-green-600">Active</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">SSL Certificate</span>
                      <span className="text-sm font-medium text-green-600">Valid</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Backup Status</span>
                      <span className="text-sm font-medium text-green-600">Up to date</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">2FA Enabled</span>
                      <span className="text-sm font-medium text-green-600">Yes</span>
                    </div>
                  </div>
                </div>

                <div className="bg-gray-50 rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-3">Quick Actions</h4>
                  <div className="space-y-2">
                    <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                      Run Security Scan
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                      Update Firewall Rules
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                      Generate Security Report
                    </button>
                    <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                      View Audit Logs
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'firewall' && (
            <div className="space-y-4">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Rule Name</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Type</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Priority</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Last Updated</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {firewallRules.map((rule) => (
                      <tr key={rule.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-4 px-4 font-medium text-gray-900">{rule.name}</td>
                        <td className="py-4 px-4 text-gray-600">{rule.type}</td>
                        <td className="py-4 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            rule.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                          }`}>
                            {rule.status}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            rule.priority === 'Critical' ? 'bg-red-100 text-red-800' :
                            rule.priority === 'High' ? 'bg-orange-100 text-orange-800' :
                            rule.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {rule.priority}
                          </span>
                        </td>
                        <td className="py-4 px-4 text-gray-600">{rule.lastUpdated}</td>
                        <td className="py-4 px-4">
                          <div className="flex items-center space-x-2">
                            <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                              <i className="ri-edit-line text-gray-600"></i>
                            </button>
                            <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                              <i className="ri-play-line text-green-600"></i>
                            </button>
                            <button className="p-2 hover:bg-red-100 rounded-lg cursor-pointer">
                              <i className="ri-delete-bin-line text-red-600"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {activeTab === 'backup' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Backup Schedule</h3>
                <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 cursor-pointer whitespace-nowrap">
                  <i className="ri-add-line mr-2"></i>
                  Add Backup Job
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Backup Name</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Frequency</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Last Run</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Next Run</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {backupSchedule.map((backup) => (
                      <tr key={backup.id} className="border-b border-gray-100 hover:bg-gray-50">
                        <td className="py-4 px-4 font-medium text-gray-900">{backup.name}</td>
                        <td className="py-4 px-4 text-gray-600">{backup.frequency}</td>
                        <td className="py-4 px-4 text-gray-600">{backup.lastRun}</td>
                        <td className="py-4 px-4 text-gray-600">{backup.nextRun}</td>
                        <td className="py-4 px-4">
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            backup.status === 'Success' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                          }`}>
                            {backup.status}
                          </span>
                        </td>
                        <td className="py-4 px-4">
                          <div className="flex items-center space-x-2">
                            <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                              <i className="ri-play-line text-green-600"></i>
                            </button>
                            <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                              <i className="ri-edit-line text-gray-600"></i>
                            </button>
                            <button className="p-2 hover:bg-red-100 rounded-lg cursor-pointer">
                              <i className="ri-delete-bin-line text-red-600"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>

      {showAddRuleModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Add Security Rule</h3>
              <button
                onClick={() => setShowAddRuleModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rule Name</label>
                <input
                  type="text"
                  placeholder="e.g., Block Bot Traffic"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rule Type</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500">
                  <option>IP Block</option>
                  <option>Rate Limit</option>
                  <option>WAF Rule</option>
                  <option>DDoS Shield</option>
                  <option>Geo Filter</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500">
                  <option>Low</option>
                  <option>Medium</option>
                  <option>High</option>
                  <option>Critical</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Rule Configuration</label>
                <textarea
                  placeholder="Enter rule configuration..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  rows={3}
                ></textarea>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="activeRule"
                  className="w-4 h-4 text-red-600 focus:ring-red-500 border-gray-300 rounded cursor-pointer"
                />
                <label htmlFor="activeRule" className="text-sm text-gray-700 cursor-pointer">
                  Activate rule immediately
                </label>
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-4 mt-6">
              <button
                onClick={() => setShowAddRuleModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
              <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
                Add Rule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}