'use client';

import { useState } from 'react';

export default function ThemeManagement() {
  const [activeTheme, setActiveTheme] = useState('default');
  const [showCustomizeModal, setShowCustomizeModal] = useState(false);

  const themes = [
    { id: 'default', name: 'Default Theme', description: 'Clean and modern design', preview: '#FF6B6B', active: true },
    { id: 'dark', name: 'Dark Theme', description: 'Dark mode optimized', preview: '#1A1A1A', active: false },
    { id: 'purple', name: 'Purple Theme', description: 'Purple gradient style', preview: '#8B5CF6', active: false },
    { id: 'blue', name: 'Blue Theme', description: 'Professional blue theme', preview: '#3B82F6', active: false },
    { id: 'green', name: 'Green Theme', description: 'Nature inspired design', preview: '#10B981', active: false },
    { id: 'orange', name: 'Orange Theme', description: 'Warm and vibrant', preview: '#F59E0B', active: false },
  ];

  const customizationOptions = {
    primaryColor: '#FF6B6B',
    secondaryColor: '#4ECDC4',
    backgroundColor: '#FFFFFF',
    textColor: '#1F2937',
    borderRadius: '8px',
    fontFamily: 'Inter',
    headerStyle: 'modern',
    buttonStyle: 'rounded',
    cardStyle: 'elevated'
  };

  const handleThemeChange = (themeId: string) => {
    setActiveTheme(themeId);
    console.log('Theme changed to:', themeId);
  };

  const handleCustomize = () => {
    setShowCustomizeModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Theme Management</h2>
        <div className="flex items-center space-x-4">
          <button 
            onClick={handleCustomize}
            className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 cursor-pointer whitespace-nowrap"
          >
            <i className="ri-palette-line mr-2"></i>
            Customize Theme
          </button>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
            <i className="ri-download-line mr-2"></i>
            Import Theme
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Available Themes</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {themes.map((theme) => (
            <div key={theme.id} className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
              activeTheme === theme.id ? 'border-red-500 bg-red-50' : 'border-gray-200 hover:border-gray-300'
            }`}>
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-semibold text-gray-900">{theme.name}</h4>
                {theme.active && (
                  <span className="px-2 py-1 bg-green-100 text-green-800 text-xs rounded-full">
                    Active
                  </span>
                )}
              </div>
              
              <div 
                className="w-full h-24 rounded-lg mb-3"
                style={{ backgroundColor: theme.preview }}
              ></div>
              
              <p className="text-sm text-gray-600 mb-4">{theme.description}</p>
              
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => handleThemeChange(theme.id)}
                  className={`flex-1 px-3 py-2 rounded-lg text-sm font-medium cursor-pointer whitespace-nowrap ${
                    activeTheme === theme.id
                      ? 'bg-red-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  {activeTheme === theme.id ? 'Active' : 'Select'}
                </button>
                <button className="px-3 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50 cursor-pointer">
                  Preview
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Theme Settings</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Primary Color</label>
            <div className="flex items-center space-x-3">
              <input
                type="color"
                value={customizationOptions.primaryColor}
                className="w-12 h-10 border border-gray-300 rounded-lg cursor-pointer"
              />
              <input
                type="text"
                value={customizationOptions.primaryColor}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Secondary Color</label>
            <div className="flex items-center space-x-3">
              <input
                type="color"
                value={customizationOptions.secondaryColor}
                className="w-12 h-10 border border-gray-300 rounded-lg cursor-pointer"
              />
              <input
                type="text"
                value={customizationOptions.secondaryColor}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Background Color</label>
            <div className="flex items-center space-x-3">
              <input
                type="color"
                value={customizationOptions.backgroundColor}
                className="w-12 h-10 border border-gray-300 rounded-lg cursor-pointer"
              />
              <input
                type="text"
                value={customizationOptions.backgroundColor}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Text Color</label>
            <div className="flex items-center space-x-3">
              <input
                type="color"
                value={customizationOptions.textColor}
                className="w-12 h-10 border border-gray-300 rounded-lg cursor-pointer"
              />
              <input
                type="text"
                value={customizationOptions.textColor}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Font Family</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500">
              <option value="Inter">Inter</option>
              <option value="Roboto">Roboto</option>
              <option value="Arial">Arial</option>
              <option value="Helvetica">Helvetica</option>
              <option value="Times New Roman">Times New Roman</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Border Radius</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500">
              <option value="4px">Small (4px)</option>
              <option value="8px">Medium (8px)</option>
              <option value="12px">Large (12px)</option>
              <option value="16px">Extra Large (16px)</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Header Style</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500">
              <option value="modern">Modern</option>
              <option value="classic">Classic</option>
              <option value="minimal">Minimal</option>
              <option value="bold">Bold</option>
            </select>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Button Style</label>
            <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500">
              <option value="rounded">Rounded</option>
              <option value="square">Square</option>
              <option value="pill">Pill</option>
              <option value="outline">Outline</option>
            </select>
          </div>
        </div>
        
        <div className="flex items-center justify-end space-x-4 mt-6">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap">
            Reset to Default
          </button>
          <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
            Save Changes
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Theme Preview</h3>
        
        <div className="border border-gray-300 rounded-lg p-4 bg-gray-50">
          <div className="bg-white rounded-lg p-4 mb-4">
            <div className="flex items-center justify-between p-3 bg-red-600 text-white rounded-lg mb-4">
              <div className="flex items-center space-x-2">
                <i className="ri-home-line"></i>
                <span>Logo</span>
              </div>
              <div className="flex items-center space-x-4">
                <i className="ri-search-line"></i>
                <i className="ri-notification-line"></i>
                <i className="ri-user-line"></i>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-blue-600 rounded-full"></div>
                <div>
                  <div className="w-24 h-4 bg-gray-300 rounded"></div>
                  <div className="w-16 h-3 bg-gray-200 rounded mt-1"></div>
                </div>
              </div>
              
              <div className="w-full h-32 bg-gray-300 rounded-lg"></div>
              
              <div className="flex items-center space-x-4">
                <button className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm">
                  Subscribe
                </button>
                <button className="px-4 py-2 border border-gray-300 rounded-lg text-sm">
                  Message
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showCustomizeModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Advanced Customization</h3>
              <button
                onClick={() => setShowCustomizeModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Custom CSS</label>
                <textarea
                  placeholder="Enter custom CSS code..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500 font-mono text-sm"
                  rows={6}
                ></textarea>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Logo Upload</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                  <i className="ri-upload-cloud-line text-2xl text-gray-400 mb-2"></i>
                  <p className="text-sm text-gray-600">Click to upload logo</p>
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Favicon Upload</label>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
                  <i className="ri-upload-cloud-line text-2xl text-gray-400 mb-2"></i>
                  <p className="text-sm text-gray-600">Click to upload favicon</p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-4 mt-6">
              <button
                onClick={() => setShowCustomizeModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
              <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
                Apply Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}