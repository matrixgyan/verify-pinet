'use client';

import { useState } from 'react';

export default function SystemLogs() {
  const [activeTab, setActiveTab] = useState('system');
  const [filterLevel, setFilterLevel] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const systemLogs = [
    { id: 1, timestamp: '2024-03-15 10:30:25', level: 'info', category: 'System', message: 'Database backup completed successfully', user: 'System', ip: '127.0.0.1' },
    { id: 2, timestamp: '2024-03-15 10:28:12', level: 'warning', category: 'Security', message: 'Multiple failed login attempts from IP 192.168.1.100', user: 'anonymous', ip: '192.168.1.100' },
    { id: 3, timestamp: '2024-03-15 10:25:45', level: 'error', category: 'Payment', message: 'Payment processing failed for user ID 12345', user: 'sarah_johnson', ip: '203.0.113.1' },
    { id: 4, timestamp: '2024-03-15 10:23:18', level: 'info', category: 'User', message: 'User registration completed', user: 'new_user_456', ip: '10.0.0.1' },
    { id: 5, timestamp: '2024-03-15 10:20:33', level: 'debug', category: 'System', message: 'Cache cleared successfully', user: 'admin', ip: '172.16.0.1' },
  ];

  const auditLogs = [
    { id: 1, timestamp: '2024-03-15 10:30:00', action: 'User Created', user: 'admin', target: 'user_12345', details: 'Created new user account', ip: '10.0.0.1' },
    { id: 2, timestamp: '2024-03-15 10:28:15', action: 'Content Approved', user: 'moderator1', target: 'content_67890', details: 'Approved content after review', ip: '192.168.1.1' },
    { id: 3, timestamp: '2024-03-15 10:25:30', action: 'Settings Updated', user: 'admin', target: 'system_settings', details: 'Updated payment configuration', ip: '10.0.0.1' },
    { id: 4, timestamp: '2024-03-15 10:22:45', action: 'User Suspended', user: 'admin', target: 'user_54321', details: 'User suspended for policy violation', ip: '10.0.0.1' },
    { id: 5, timestamp: '2024-03-15 10:20:00', action: 'Backup Created', user: 'system', target: 'database', details: 'Automated daily backup created', ip: '127.0.0.1' },
  ];

  const securityLogs = [
    { id: 1, timestamp: '2024-03-15 10:30:15', event: 'Login Attempt', status: 'Success', user: 'admin', ip: '10.0.0.1', location: 'New York, US' },
    { id: 2, timestamp: '2024-03-15 10:28:30', event: 'Login Attempt', status: 'Failed', user: 'unknown', ip: '192.168.1.100', location: 'Unknown' },
    { id: 3, timestamp: '2024-03-15 10:26:45', event: 'Password Change', status: 'Success', user: 'sarah_johnson', ip: '203.0.113.1', location: 'California, US' },
    { id: 4, timestamp: '2024-03-15 10:24:00', event: 'API Access', status: 'Success', user: 'api_user', ip: '172.16.0.1', location: 'London, UK' },
    { id: 5, timestamp: '2024-03-15 10:21:15', event: 'File Upload', status: 'Blocked', user: 'mike_chen', ip: '10.0.0.5', location: 'Tokyo, JP' },
  ];

  const errorLogs = [
    { id: 1, timestamp: '2024-03-15 10:30:10', error: 'Database Connection Timeout', severity: 'High', component: 'Database', message: 'Connection to primary database timed out after 30 seconds', stack: 'Error at line 245 in db.js' },
    { id: 2, timestamp: '2024-03-15 10:27:25', error: 'Payment Gateway Error', severity: 'Medium', component: 'Payment', message: 'Stripe API returned error code 4000', stack: 'Error at line 120 in payment.js' },
    { id: 3, timestamp: '2024-03-15 10:24:40', error: 'File Upload Failed', severity: 'Low', component: 'Storage', message: 'File upload to S3 bucket failed', stack: 'Error at line 67 in upload.js' },
    { id: 4, timestamp: '2024-03-15 10:22:55', error: 'Email Delivery Failed', severity: 'Medium', component: 'Email', message: 'SMTP server connection refused', stack: 'Error at line 89 in email.js' },
    { id: 5, timestamp: '2024-03-15 10:19:30', error: 'Cache Miss', severity: 'Low', component: 'Cache', message: 'Redis cache key not found', stack: 'Error at line 34 in cache.js' },
  ];

  const filteredLogs = () => {
    let logs = [];
    switch (activeTab) {
      case 'system':
        logs = systemLogs;
        break;
      case 'audit':
        logs = auditLogs;
        break;
      case 'security':
        logs = securityLogs;
        break;
      case 'error':
        logs = errorLogs;
        break;
      default:
        logs = systemLogs;
    }

    if (filterLevel !== 'all') {
      logs = logs.filter(log => log.level === filterLevel || log.severity === filterLevel || log.status === filterLevel);
    }

    if (searchTerm) {
      logs = logs.filter(log => 
        JSON.stringify(log).toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    return logs;
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'error':
      case 'High':
      case 'Failed':
        return 'bg-red-100 text-red-800';
      case 'warning':
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'info':
      case 'Low':
      case 'Success':
        return 'bg-green-100 text-green-800';
      case 'debug':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">System Logs</h2>
        <div className="flex items-center space-x-4">
          <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 cursor-pointer whitespace-nowrap">
            <i className="ri-refresh-line mr-2"></i>
            Refresh Logs
          </button>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
            <i className="ri-download-line mr-2"></i>
            Export Logs
          </button>
        </div>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('system')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'system'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              System Logs
            </button>
            <button
              onClick={() => setActiveTab('audit')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'audit'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Audit Logs
            </button>
            <button
              onClick={() => setActiveTab('security')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'security'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Security Logs
            </button>
            <button
              onClick={() => setActiveTab('error')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'error'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Error Logs
            </button>
          </nav>
        </div>

        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search logs..."
                  className="w-64 px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
              </div>
              
              <select
                value={filterLevel}
                onChange={(e) => setFilterLevel(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
              >
                <option value="all">All Levels</option>
                <option value="error">Error</option>
                <option value="warning">Warning</option>
                <option value="info">Info</option>
                <option value="debug">Debug</option>
              </select>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-600">Auto-refresh:</span>
              <label className="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" className="sr-only peer" />
                <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-red-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-red-600"></div>
              </label>
            </div>
          </div>

          <div className="space-y-3">
            {filteredLogs().map((log) => (
              <div key={log.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <span className="text-sm font-mono text-gray-500">{log.timestamp}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        getLevelColor(log.level || log.severity || log.status)
                      }`}>
                        {log.level || log.severity || log.status}
                      </span>
                      {log.category && (
                        <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs">
                          {log.category}
                        </span>
                      )}
                    </div>
                    
                    <p className="text-sm text-gray-900 mb-2">
                      {log.message || log.details || log.error}
                    </p>
                    
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      {log.user && <span>User: {log.user}</span>}
                      {log.ip && <span>IP: {log.ip}</span>}
                      {log.location && <span>Location: {log.location}</span>}
                      {log.component && <span>Component: {log.component}</span>}
                      {log.target && <span>Target: {log.target}</span>}
                    </div>
                    
                    {log.stack && (
                      <details className="mt-2">
                        <summary className="text-xs text-gray-500 cursor-pointer hover:text-gray-700">
                          Show stack trace
                        </summary>
                        <pre className="mt-1 text-xs text-gray-600 bg-gray-50 p-2 rounded overflow-x-auto">
                          {log.stack}
                        </pre>
                      </details>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                      <i className="ri-more-line text-gray-600"></i>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {filteredLogs().length === 0 && (
            <div className="text-center py-12">
              <i className="ri-file-list-line text-4xl text-gray-400 mb-4"></i>
              <p className="text-gray-600">No logs found matching your criteria</p>
            </div>
          )}

          <div className="flex items-center justify-between mt-6 pt-6 border-t border-gray-200">
            <p className="text-sm text-gray-600">
              Showing {filteredLogs().length} logs
            </p>
            <div className="flex items-center space-x-2">
              <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
                Previous
              </button>
              <button className="px-3 py-1 bg-red-600 text-white rounded-lg cursor-pointer">1</button>
              <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">2</button>
              <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">3</button>
              <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}