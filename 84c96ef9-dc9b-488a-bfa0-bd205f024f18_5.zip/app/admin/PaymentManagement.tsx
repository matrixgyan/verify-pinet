'use client';

import { useState } from 'react';

export default function PaymentManagement() {
  const [activeTab, setActiveTab] = useState('methods');
  const [showAddMethod, setShowAddMethod] = useState(false);

  const paymentMethods = [
    { id: 1, name: 'Stripe', type: 'Credit Card', status: 'Active', commission: '2.9%', lastUsed: '2024-03-15' },
    { id: 2, name: 'PayPal', type: 'Digital Wallet', status: 'Active', commission: '3.5%', lastUsed: '2024-03-14' },
    { id: 3, name: 'Crypto Wallet', type: 'Cryptocurrency', status: 'Inactive', commission: '1.5%', lastUsed: '2024-03-10' },
    { id: 4, name: 'Bank Transfer', type: 'Direct Transfer', status: 'Active', commission: '0.5%', lastUsed: '2024-03-13' },
  ];

  const transactions = [
    { id: 1, user: 'Sarah Johnson', amount: '$299.99', method: 'Stripe', status: 'Completed', date: '2024-03-15 10:30' },
    { id: 2, user: 'Mike Chen', amount: '$49.99', method: 'PayPal', status: 'Pending', date: '2024-03-15 09:15' },
    { id: 3, user: 'Emma Wilson', amount: '$199.99', method: 'Stripe', status: 'Failed', date: '2024-03-14 16:45' },
    { id: 4, user: 'Alex Brown', amount: '$99.99', method: 'Bank Transfer', status: 'Completed', date: '2024-03-14 14:20' },
    { id: 5, user: 'Lisa Davis', amount: '$149.99', method: 'Crypto Wallet', status: 'Completed', date: '2024-03-14 11:30' },
  ];

  const payouts = [
    { id: 1, creator: 'Sarah Johnson', amount: '$2,450.00', method: 'Bank Transfer', status: 'Processed', date: '2024-03-15' },
    { id: 2, creator: 'Emma Wilson', amount: '$1,890.00', method: 'PayPal', status: 'Pending', date: '2024-03-15' },
    { id: 3, creator: 'Mike Chen', amount: '$1,234.00', method: 'Stripe', status: 'Processing', date: '2024-03-14' },
    { id: 4, creator: 'Alex Brown', amount: '$987.00', method: 'Bank Transfer', status: 'Processed', date: '2024-03-14' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Payment Management</h2>
        <button 
          onClick={() => setShowAddMethod(true)}
          className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap"
        >
          <i className="ri-add-line mr-2"></i>
          Add Payment Method
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            <button
              onClick={() => setActiveTab('methods')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'methods'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Payment Methods
            </button>
            <button
              onClick={() => setActiveTab('transactions')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'transactions'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Transactions
            </button>
            <button
              onClick={() => setActiveTab('payouts')}
              className={`py-4 px-2 border-b-2 font-medium text-sm whitespace-nowrap cursor-pointer ${
                activeTab === 'payouts'
                  ? 'border-red-500 text-red-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`}
            >
              Creator Payouts
            </button>
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'methods' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {paymentMethods.map((method) => (
                  <div key={method.id} className="border border-gray-200 rounded-lg p-4 hover:border-red-300 transition-colors">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-semibold text-gray-900">{method.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        method.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                      }`}>
                        {method.status}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-2">{method.type}</p>
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-500">Commission: {method.commission}</span>
                      <span className="text-gray-500">Last used: {method.lastUsed}</span>
                    </div>
                    <div className="flex items-center justify-between mt-3">
                      <button className="text-sm text-red-600 hover:text-red-700 cursor-pointer">
                        Configure
                      </button>
                      <button className="text-sm text-gray-600 hover:text-gray-700 cursor-pointer">
                        View Details
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'transactions' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-900">User</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Amount</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Method</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((transaction) => (
                    <tr key={transaction.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">{transaction.user[0]}</span>
                          </div>
                          <span className="font-medium text-gray-900">{transaction.user}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 font-medium text-gray-900">{transaction.amount}</td>
                      <td className="py-4 px-4 text-gray-600">{transaction.method}</td>
                      <td className="py-4 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          transaction.status === 'Completed' ? 'bg-green-100 text-green-800' :
                          transaction.status === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {transaction.status}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{transaction.date}</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                            <i className="ri-eye-line text-gray-600"></i>
                          </button>
                          <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                            <i className="ri-download-line text-gray-600"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'payouts' && (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-200">
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Creator</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Amount</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Method</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Date</th>
                    <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {payouts.map((payout) => (
                    <tr key={payout.id} className="border-b border-gray-100 hover:bg-gray-50">
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                            <span className="text-white text-sm font-bold">{payout.creator[0]}</span>
                          </div>
                          <span className="font-medium text-gray-900">{payout.creator}</span>
                        </div>
                      </td>
                      <td className="py-4 px-4 font-medium text-gray-900">{payout.amount}</td>
                      <td className="py-4 px-4 text-gray-600">{payout.method}</td>
                      <td className="py-4 px-4">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          payout.status === 'Processed' ? 'bg-green-100 text-green-800' :
                          payout.status === 'Processing' ? 'bg-blue-100 text-blue-800' :
                          'bg-yellow-100 text-yellow-800'
                        }`}>
                          {payout.status}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-gray-600">{payout.date}</td>
                      <td className="py-4 px-4">
                        <div className="flex items-center space-x-2">
                          <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                            <i className="ri-eye-line text-gray-600"></i>
                          </button>
                          <button className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer">
                            <i className="ri-download-line text-gray-600"></i>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {showAddMethod && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Add Payment Method</h3>
              <button
                onClick={() => setShowAddMethod(false)}
                className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Method Name</label>
                <input
                  type="text"
                  placeholder="e.g., Stripe, PayPal"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Type</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500">
                  <option>Credit Card</option>
                  <option>Digital Wallet</option>
                  <option>Cryptocurrency</option>
                  <option>Bank Transfer</option>
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Commission Rate (%)</label>
                <input
                  type="number"
                  step="0.1"
                  placeholder="2.9"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">API Key</label>
                <input
                  type="password"
                  placeholder="Enter API key"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-4 mt-6">
              <button
                onClick={() => setShowAddMethod(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
              <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
                Add Method
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}