'use client';

interface AdminSidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function AdminSidebar({ activeTab, setActiveTab }: AdminSidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: 'ri-dashboard-line' },
    { id: 'users', label: 'User Management', icon: 'ri-user-settings-line' },
    { id: 'payments', label: 'Payment Methods', icon: 'ri-bank-card-line' },
    { id: 'subscriptions', label: 'Subscriptions', icon: 'ri-vip-crown-line' },
    { id: 'content', label: 'Content Moderation', icon: 'ri-shield-check-line' },
    { id: 'themes', label: 'Theme Management', icon: 'ri-palette-line' },
    { id: 'settings', label: 'Website Settings', icon: 'ri-settings-line' },
    { id: 'security', label: 'Security Settings', icon: 'ri-lock-line' },
    { id: 'analytics', label: 'Analytics & Reports', icon: 'ri-bar-chart-line' },
    { id: 'logs', label: 'System Logs', icon: 'ri-file-text-line' },
  ];

  return (
    <div className="w-64 bg-white shadow-lg h-screen sticky top-0 border-r border-gray-200">
      <div className="p-6">
        <nav className="space-y-2">
          {menuItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-colors cursor-pointer whitespace-nowrap ${
                activeTab === item.id
                  ? 'bg-red-50 text-red-600 border-r-2 border-red-600'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
              }`}
            >
              <i className={`${item.icon} text-lg`}></i>
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
      </div>
      
      <div className="absolute bottom-0 w-full p-6 border-t border-gray-200">
        <div className="bg-red-50 p-4 rounded-lg">
          <div className="flex items-center space-x-2">
            <i className="ri-shield-check-line text-red-600"></i>
            <span className="text-sm font-medium text-red-600">System Status</span>
          </div>
          <p className="text-xs text-gray-600 mt-1">All systems operational</p>
        </div>
      </div>
    </div>
  );
}