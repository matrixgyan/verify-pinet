'use client';

import { useState } from 'react';

export default function UserManagement() {
  const [searchTerm, setSearchTerm] = useState('');
  const [userFilter, setUserFilter] = useState('all');
  const [showUserModal, setShowUserModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);

  const users = [
    { id: 1, name: 'Sarah Johnson', email: 'sarah@example.com', type: 'Creator', status: 'Active', verified: true, joinDate: '2024-01-15', subscribers: 2340, earnings: '$12,450' },
    { id: 2, name: 'Mike Chen', email: 'mike@example.com', type: 'Fan', status: 'Active', verified: false, joinDate: '2024-02-20', subscribers: 0, earnings: '$0' },
    { id: 3, name: 'Emma Wilson', email: 'emma@example.com', type: 'Creator', status: 'Suspended', verified: true, joinDate: '2024-01-10', subscribers: 1890, earnings: '$9,870' },
    { id: 4, name: 'Alex Brown', email: 'alex@example.com', type: 'Fan', status: 'Active', verified: true, joinDate: '2024-03-05', subscribers: 0, earnings: '$0' },
    { id: 5, name: 'Lisa Davis', email: 'lisa@example.com', type: 'Creator', status: 'Pending', verified: false, joinDate: '2024-03-10', subscribers: 1098, earnings: '$6,890' },
  ];

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = userFilter === 'all' || user.type.toLowerCase() === userFilter;
    return matchesSearch && matchesFilter;
  });

  const handleUserAction = (userId: number, action: string) => {
    console.log(`Action: ${action} for user: ${userId}`);
  };

  const handleUserEdit = (user: any) => {
    setSelectedUser(user);
    setShowUserModal(true);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">User Management</h2>
        <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
          <i className="ri-add-line mr-2"></i>
          Add New User
        </button>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <input
                type="text"
                placeholder="Search users..."
                className="w-64 px-4 py-2 pl-10 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            </div>
            
            <select
              value={userFilter}
              onChange={(e) => setUserFilter(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              <option value="all">All Users</option>
              <option value="creator">Creators</option>
              <option value="fan">Fans</option>
            </select>
          </div>
          
          <div className="flex items-center space-x-2">
            <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap">
              <i className="ri-download-line mr-2"></i>
              Export
            </button>
            <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap">
              <i className="ri-filter-line mr-2"></i>
              Filter
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 font-medium text-gray-900">User</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Type</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Status</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Verified</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Join Date</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Subscribers</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Earnings</th>
                <th className="text-left py-3 px-4 font-medium text-gray-900">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user) => (
                <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                        <span className="text-white text-sm font-bold">{user.name[0]}</span>
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{user.name}</p>
                        <p className="text-sm text-gray-500">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      user.type === 'Creator' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {user.type}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      user.status === 'Active' ? 'bg-green-100 text-green-800' :
                      user.status === 'Suspended' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {user.status}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    {user.verified ? (
                      <i className="ri-verified-badge-fill text-blue-600 text-lg"></i>
                    ) : (
                      <i className="ri-close-circle-fill text-gray-400 text-lg"></i>
                    )}
                  </td>
                  <td className="py-4 px-4 text-sm text-gray-600">{user.joinDate}</td>
                  <td className="py-4 px-4 text-sm text-gray-600">{user.subscribers.toLocaleString()}</td>
                  <td className="py-4 px-4 text-sm font-medium text-gray-900">{user.earnings}</td>
                  <td className="py-4 px-4">
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleUserEdit(user)}
                        className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
                      >
                        <i className="ri-edit-line text-gray-600"></i>
                      </button>
                      <button
                        onClick={() => handleUserAction(user.id, 'suspend')}
                        className="p-2 hover:bg-red-100 rounded-lg cursor-pointer"
                      >
                        <i className="ri-forbid-line text-red-600"></i>
                      </button>
                      <button
                        onClick={() => handleUserAction(user.id, 'delete')}
                        className="p-2 hover:bg-red-100 rounded-lg cursor-pointer"
                      >
                        <i className="ri-delete-bin-line text-red-600"></i>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between mt-6">
          <p className="text-sm text-gray-600">
            Showing {filteredUsers.length} of {users.length} users
          </p>
          <div className="flex items-center space-x-2">
            <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
              Previous
            </button>
            <button className="px-3 py-1 bg-red-600 text-white rounded-lg cursor-pointer">1</button>
            <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">2</button>
            <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">3</button>
            <button className="px-3 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer">
              Next
            </button>
          </div>
        </div>
      </div>

      {showUserModal && selectedUser && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-6 w-96">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Edit User</h3>
              <button
                onClick={() => setShowUserModal(false)}
                className="p-2 hover:bg-gray-100 rounded-lg cursor-pointer"
              >
                <i className="ri-close-line text-gray-600"></i>
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                <input
                  type="text"
                  defaultValue={selectedUser.name}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input
                  type="email"
                  defaultValue={selectedUser.email}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                <select
                  defaultValue={selectedUser.status}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
                >
                  <option value="Active">Active</option>
                  <option value="Suspended">Suspended</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="verified"
                  defaultChecked={selectedUser.verified}
                  className="w-4 h-4 text-red-600 focus:ring-red-500 border-gray-300 rounded cursor-pointer"
                />
                <label htmlFor="verified" className="text-sm text-gray-700 cursor-pointer">
                  Verified user
                </label>
              </div>
            </div>
            
            <div className="flex items-center justify-end space-x-4 mt-6">
              <button
                onClick={() => setShowUserModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer whitespace-nowrap"
              >
                Cancel
              </button>
              <button className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
                Save Changes
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}