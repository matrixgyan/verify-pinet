'use client';

import { useState } from 'react';
import { SimpleAreaChart, BarChart, LineChart, PieChart, Area, Bar, Line, Pie, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';

export default function AnalyticsReports() {
  const [dateRange, setDateRange] = useState('7days');
  const [reportType, setReportType] = useState('overview');

  const revenueData = [
    { name: 'Jan', revenue: 12000, users: 1200 },
    { name: 'Feb', revenue: 15000, users: 1400 },
    { name: 'Mar', revenue: 18000, users: 1600 },
    { name: 'Apr', revenue: 22000, users: 1800 },
    { name: 'May', revenue: 25000, users: 2000 },
    { name: 'Jun', revenue: 28000, users: 2200 },
    { name: 'Jul', revenue: 32000, users: 2400 },
  ];

  const userGrowthData = [
    { name: 'Week 1', creators: 45, fans: 1200 },
    { name: 'Week 2', creators: 52, fans: 1350 },
    { name: 'Week 3', creators: 48, fans: 1420 },
    { name: 'Week 4', creators: 61, fans: 1580 },
    { name: 'Week 5', creators: 55, fans: 1650 },
    { name: 'Week 6', creators: 67, fans: 1780 },
    { name: 'Week 7', creators: 73, fans: 1920 },
  ];

  const contentDistribution = [
    { name: 'Images', value: 45, color: '#FF6B6B' },
    { name: 'Videos', value: 35, color: '#4ECDC4' },
    { name: 'Text Posts', value: 15, color: '#45B7D1' },
    { name: 'Live Streams', value: 5, color: '#96CEB4' },
  ];

  const subscriptionData = [
    { name: 'Free', value: 5240, color: '#95A5A6' },
    { name: 'Premium', value: 2840, color: '#3498DB' },
    { name: 'VIP', value: 1560, color: '#E74C3C' },
    { name: 'Creator', value: 890, color: '#F39C12' },
  ];

  const topCreators = [
    { name: 'Sarah Johnson', revenue: '$12,450', subscribers: 2340, growth: '+18%' },
    { name: 'Emma Wilson', revenue: '$9,870', subscribers: 1890, growth: '+25%' },
    { name: 'Mike Chen', revenue: '$8,450', subscribers: 1567, growth: '+12%' },
    { name: 'Alex Brown', revenue: '$7,230', subscribers: 1234, growth: '+8%' },
    { name: 'Lisa Davis', revenue: '$6,890', subscribers: 1098, growth: '+15%' },
  ];

  const keyMetrics = {
    totalRevenue: 245670,
    totalUsers: 45892,
    activeSubscriptions: 12456,
    contentPosts: 8901,
    averageSessionTime: '24m 35s',
    conversionRate: 15.2,
    churnRate: 3.8,
    customerLifetimeValue: 189.50
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-gray-900">Analytics & Reports</h2>
        <div className="flex items-center space-x-4">
          <select
            value={dateRange}
            onChange={(e) => setDateRange(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-red-500"
          >
            <option value="7days">Last 7 days</option>
            <option value="30days">Last 30 days</option>
            <option value="90days">Last 90 days</option>
            <option value="1year">Last year</option>
          </select>
          <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 cursor-pointer whitespace-nowrap">
            <i className="ri-download-line mr-2"></i>
            Export Report
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900">${keyMetrics.totalRevenue.toLocaleString()}</p>
              <p className="text-sm text-green-600">+12% from last period</p>
            </div>
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <i className="ri-money-dollar-circle-line text-green-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Users</p>
              <p className="text-2xl font-bold text-gray-900">{keyMetrics.totalUsers.toLocaleString()}</p>
              <p className="text-sm text-blue-600">+8% from last period</p>
            </div>
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <i className="ri-user-line text-blue-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Active Subscriptions</p>
              <p className="text-2xl font-bold text-gray-900">{keyMetrics.activeSubscriptions.toLocaleString()}</p>
              <p className="text-sm text-purple-600">+15% from last period</p>
            </div>
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <i className="ri-vip-crown-line text-purple-600 text-xl"></i>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Content Posts</p>
              <p className="text-2xl font-bold text-gray-900">{keyMetrics.contentPosts.toLocaleString()}</p>
              <p className="text-sm text-orange-600">+22% from last period</p>
            </div>
            <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
              <i className="ri-file-text-line text-orange-600 text-xl"></i>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Revenue Trend</h3>
          <ResponsiveContainer width="100%" height={300}>
            <SimpleAreaChart data={revenueData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Area type="monotone" dataKey="revenue" stroke="#FF6B6B" fill="#FF6B6B" fillOpacity={0.6} />
            </SimpleAreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">User Growth</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={userGrowthData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="creators" fill="#4ECDC4" />
              <Bar dataKey="fans" fill="#45B7D1" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Content Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={contentDistribution}
                cx="50%"
                cy="50%"
                outerRadius={80}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {contentDistribution.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Subscription Breakdown</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={subscriptionData}
                cx="50%"
                cy="50%"
                outerRadius={80}
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
              >
                {subscriptionData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900">Top Performing Creators</h3>
            <button className="text-sm text-red-600 hover:text-red-700 cursor-pointer">
              View all
            </button>
          </div>
          
          <div className="space-y-4">
            {topCreators.map((creator, index) => (
              <div key={index} className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-purple-600 rounded-full flex items-center justify-center">
                    <span className="text-white text-sm font-bold">{creator.name[0]}</span>
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">{creator.name}</p>
                    <p className="text-sm text-gray-500">{creator.subscribers} subscribers</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900">{creator.revenue}</p>
                  <p className="text-sm text-green-600">{creator.growth}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Key Performance Metrics</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Average Session Time</span>
              <span className="font-medium text-gray-900">{keyMetrics.averageSessionTime}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Conversion Rate</span>
              <span className="font-medium text-gray-900">{keyMetrics.conversionRate}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Churn Rate</span>
              <span className="font-medium text-gray-900">{keyMetrics.churnRate}%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Customer Lifetime Value</span>
              <span className="font-medium text-gray-900">${keyMetrics.customerLifetimeValue}</span>
            </div>
          </div>
          
          <div className="mt-6 pt-6 border-t border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-3">Quick Reports</h4>
            <div className="space-y-2">
              <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                Daily Revenue Report
              </button>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                User Activity Report
              </button>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                Content Performance Report
              </button>
              <button className="w-full text-left px-3 py-2 text-sm text-gray-700 hover:bg-gray-100 rounded-lg cursor-pointer">
                Subscription Analytics
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}